package br.cefet.acolhimed.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.cefet.acolhimed.dto.MedicoRequestDTO;
import br.cefet.acolhimed.dto.MedicoResponseDTO;
import br.cefet.acolhimed.service.MedicoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/medicos")
@Tag(name = "Medico")
public class MedicoController {

    @Autowired
    private MedicoService MedicoService;

    @GetMapping("/destaques")
    @Operation(summary = "Listar Medicos Mais Bem Avaliados")
    public ResponseEntity<List<MedicoResponseDTO>> listarMedicosBemAvaliados() {
        List<MedicoResponseDTO> Medicos = MedicoService.listarMedicosBemAvaliados();
        return ResponseEntity.ok(Medicos);
    }

    @PostMapping
    @Operation(summary = "Cadastrar Medico")
    public ResponseEntity<MedicoResponseDTO> inserir(@Valid @RequestBody MedicoRequestDTO MedicoRequestDTO) {
    	MedicoResponseDTO medicoResponseDTO = MedicoService.inserir(MedicoRequestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(medicoResponseDTO);
    }
    
    @PutMapping
    @Operation(summary = "Atualizar Medico")
    public ResponseEntity<MedicoResponseDTO> atualizar(@Valid @RequestBody MedicoRequestDTO MedicoRequestDTO) {

    	MedicoResponseDTO medicoResponseDTO = MedicoService.atualizar(MedicoRequestDTO);
        return ResponseEntity.ok(medicoResponseDTO);
    }    

}