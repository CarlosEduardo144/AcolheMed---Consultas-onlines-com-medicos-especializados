package br.cefet.acolhimed.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.cefet.acolhimed.dto.AvaliacaoRequestDTO;
import br.cefet.acolhimed.dto.AvaliacaoResponseDTO;
import java.time.ZoneId;
import br.cefet.acolhimed.entity.Avaliacao;
import br.cefet.acolhimed.entity.Consulta;
import br.cefet.acolhimed.entity.Medico;
import br.cefet.acolhimed.exception.BusinessException;
import br.cefet.acolhimed.exception.ResourceNotFoundException;
import br.cefet.acolhimed.repository.AvaliacaoRepository;
import br.cefet.acolhimed.repository.ConsultaRepository;
import br.cefet.acolhimed.repository.MedicoRepository;
import br.cefet.acolhimed.repository.PacienteRepository;

@Service
public class AvaliacaoService {

    @Autowired
    private AvaliacaoRepository avaliacaoRepository;

    @Autowired
    private MedicoRepository medicoRepository;

    @Autowired
    private PacienteRepository pacienteRepository;

    @Autowired
    private ConsultaRepository consultaRepository;

    @Transactional
    public AvaliacaoResponseDTO inserir(AvaliacaoRequestDTO dto) {

        if (dto.getNota() < 1.0 || dto.getNota() > 5.0) {
            throw new BusinessException("A nota deve ser entre 1 a 5");
        }

        Consulta consulta = consultaRepository.findById(dto.getConsultaId())
                .orElseThrow(() -> new ResourceNotFoundException("Consulta não encontrada. Id: " + dto.getConsultaId()));

        if (!medicoRepository.existsById(consulta.getMedico().getId())) {
            throw new BusinessException("Médico não encontrado. Id: " + consulta.getMedico().getId());
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        UserDetails usuario = (UserDetails) authentication.getPrincipal();

        String usuarioId = usuario.getUsername();

        if(!usuarioId.equals(consulta.getPaciente().getId())){
            throw new BusinessException("Apenas o paciente atrelado a esta consulta pode avalia-la.");
        }

        Avaliacao avaliacao = new Avaliacao();
        avaliacao.setComentario(dto.getComentario());
        avaliacao.setData(LocalDateTime.now(ZoneId.of("America/Sao_Paulo")));
        avaliacao.setNota(dto.getNota());
        avaliacao.setConsulta(consulta);

        return new AvaliacaoResponseDTO(avaliacaoRepository.save(avaliacao));
    }

    @Transactional
    public void excluir(String id) {
        if (!avaliacaoRepository.existsById(id)) {
            throw new ResourceNotFoundException("Avaliação não encontrada com ID: " + id);
        }

        avaliacaoRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<AvaliacaoResponseDTO> buscarPorMedico(String medicoId) {

        Medico medico = medicoRepository.findById(medicoId)
                .orElseThrow(() -> new ResourceNotFoundException("Médico não encontrado. Id: " + medicoId));

        return avaliacaoRepository.findByConsultaMedico(medico)
                .stream()
                .map(AvaliacaoResponseDTO::new)
                .toList();
    }
}
